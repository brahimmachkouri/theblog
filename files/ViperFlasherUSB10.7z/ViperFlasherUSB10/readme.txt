You must install the driver before running the application:

1. Connect the Viper USB Adapter to your PC. Installation should start.
2. If asked to connect to Windows Update to get the last drivers, select No.
3. Install from a specified place
4. Add the directory "driver" in the search path
5. Click "Continue" if it tells you the driver is not certified
6. The driver should be correctly installed!


For programming, switch on DIP switch 2.
Never forget to switch off DIP switch 2 after programming!

